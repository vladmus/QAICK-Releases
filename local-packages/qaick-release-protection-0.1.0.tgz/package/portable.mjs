import {readFile,writeFile,mkdir,cp,rename,mkdtemp,realpath} from 'node:fs/promises';
import {join,dirname,resolve,sep} from 'node:path';import {tmpdir} from 'node:os';import {createRequire} from 'node:module';
import {bundle,protectTree,verifyTree,files,sha256,copyNotices} from './index.mjs';
const require=createRequire(import.meta.url);
export async function archivePrepared(stage,archive,receipt) {
 await verifyTree(stage,receipt);const asar=require('@electron/asar');await asar.createPackage(stage,archive);
 const check=await mkdtemp(join(tmpdir(),'qaick-asar-verified-'));asar.extractAll(archive,check);await verifyTree(check,receipt);
 return sha256(await readFile(archive));
}
// Only freshly built output below the caller's repository is eligible. Inputs are
// preserved in a private temporary directory, never deleted or left in distribution.
export async function protectPortable(application,executable,{kind='runner',platform=process.platform,repository}={}){
 const repo=await realpath(repository),input=await realpath(application),binary=await realpath(executable);
 if(!input.startsWith(repo+sep)||!binary.startsWith(repo+sep)||!/(?:\/artifacts\/|\/dist\/desktop\/)/.test(input)||!/(?:\/artifacts\/|\/dist\/desktop\/)/.test(binary)||!input.endsWith('/resources/app')&&!input.endsWith('/Resources/app'))throw Error('Protection requires an owned repository build output, never an installed app');
 const temp=await mkdtemp(join(tmpdir(),'qaick-portable-private-')),stage=join(temp,'app');await mkdir(stage);
 const pkg=JSON.parse(await readFile(join(input,'package.json'),'utf8'));await writeFile(join(stage,'package.json'),JSON.stringify(pkg)+'\n');
 if(kind!=='mock')await verifyTree(join(repo,'dist'),JSON.parse(await readFile(join(repo,'dist.protection.json'),'utf8')));
 const entries=[];
 if(kind==='mock'){
  await cp(join(input,'public'),join(stage,'public'),{recursive:true});
  entries.push(['desktop/main.cjs','cjs'],['dist/index.js','cjs'],['dist/workspace-archive.mjs','esm'],['dist/request-execution.mjs','esm'],['dist/state/memory.js','cjs'],['dist/desktop-preload.js','cjs']);
  const browser=join(stage,'dist/browser/client/app.mjs');await mkdir(dirname(browser),{recursive:true});await bundle(join(input,'dist/browser/client/app.mjs'),browser,{platform:'browser'});
 }else{
  await cp(join(input,'dist'),join(stage,'dist'),{recursive:true});
  entries.push(['electron-dist/electron/main.js','esm'],['electron-dist/electron/preload.cjs','cjs'],['electron-dist/electron/script-preload.cjs','cjs']);
  for(const name of ['script-worker.html','desktop-build.json']){const dest=join(stage,'electron-dist/electron',name);await mkdir(dirname(dest),{recursive:true});await cp(join(input,'electron-dist/electron',name),dest);}
 }
 const memory=resolve(input,'dist/state/memory.js');
 for(const [name,format]of entries){const dest=join(stage,name);await mkdir(dirname(dest),{recursive:true});
  const plugins=name==='dist/index.js'?[{name:'shared-registry',setup(build){build.onResolve({filter:/state\/memory\.js$/},a=>resolve(a.resolveDir,a.path)===memory?{path:'./state/memory.js',external:true}:undefined);}}]:[];
  await bundle(join(input,name),dest,{format,external:['electron'],plugins});}
 await copyNotices(repo,join(stage,'notices'));
 const all=Object.keys(await files(stage)),receipt=await protectTree(stage,{platform:'node',alreadyProtected:all.filter(p=>/\.(js|mjs|cjs)$/.test(p))});await verifyTree(stage,receipt);
 const resources=dirname(input),archive=join(resources,'app.asar');await archivePrepared(stage,archive,receipt);
 await enforceAsar(executable,archive,platform);
 await rename(input,join(temp,'unprotected-build-input'));
 await writeFile(archive+'.protection.json',JSON.stringify({...receipt,asarSha256:sha256(await readFile(archive)),executableSha256:sha256(await readFile(platform==='darwin'?join(executable,'Contents/MacOS/Electron'):executable)),platform},null,2)+'\n');
 return {privateBuildInput:temp};
}
export async function enforceAsar(executable,archive,platform){
 const asar=require('@electron/asar'),{flipFuses,FuseVersion,FuseV1Options}=require('@electron/fuses');const hash=sha256(asar.getRawHeader(archive).headerString);
 if(platform==='win32'){
  const RE=require('resedit'),exe=RE.NtExecutable.from(await readFile(executable),{ignoreCert:true}),resource=RE.NtExecutableResource.from(exe);
  resource.entries=resource.entries.filter(e=>e.type!=='INTEGRITY');resource.entries.push({type:'INTEGRITY',id:'ELECTRONASAR',lang:1033,codepage:1200,bin:Buffer.from(JSON.stringify([{file:'resources\\app.asar',alg:'SHA256',value:hash}]))});resource.outputResource(exe);await writeFile(executable,Buffer.from(exe.generate()));
 }else if(platform==='darwin'){
  const plist=require('plist'),infoPath=join(executable,'Contents/Info.plist'),info=plist.parse(await readFile(infoPath,'utf8'));info.ElectronAsarIntegrity={'Resources/app.asar':{algorithm:'SHA256',hash}};await writeFile(infoPath,plist.build(info));
 }
 await flipFuses(executable,{version:FuseVersion.V1,[FuseV1Options.OnlyLoadAppFromAsar]:true,...(platform==='linux'?{}:{[FuseV1Options.EnableEmbeddedAsarIntegrityValidation]:true})});
}
