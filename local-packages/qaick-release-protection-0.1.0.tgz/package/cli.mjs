#!/usr/bin/env node
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {protectTree,verifyTree,publishWeb,copyNotices} from './index.mjs';
const [command,directory,...args]=process.argv.slice(2),root=resolve(directory??'dist'),receipt=root+'.protection.json';
if(command==='protect') {
 await copyNotices(process.cwd(),join(root,'notices'));
 const result=await protectTree(root);await writeFile(receipt,JSON.stringify(result,null,2)+'\n');await verifyTree(root,result);
 console.log('Protected and verified',root);
} else if(command==='verify') {await verifyTree(root,JSON.parse(await readFile(receipt,'utf8')));console.log('Protection verified',root);}
else if(command==='publish') {
 if(args.shift()!=='--'||!args.length)throw Error('Publication command required');
 await publishWeb(root,receipt,()=>{const r=spawnSync(args[0],args.slice(1),{stdio:'inherit'});if(r.error)throw r.error;if(r.status!==0)throw Error('Publication command failed: '+r.status);});
} else throw Error('Expected protect, verify or publish');
