# QAICK production protection tooling

Build-only shared implementation of the owner-approved 2026-11-25 protection condition. Distributed as a private local archive; never publish it to npm.

`qaick-protection protect DIRECTORY` transforms and verifies deployable assets. `verify` requires current exact-hash evidence. `publish DIRECTORY -- COMMAND` verifies before dispatch. The JavaScript API also verifies final installer receipts before release uploads. There is no skip/force publication option.

Portable packaging helpers bundle required entries and verify ASAR contents before replacing loose build inputs. They refuse installed application paths and preserve original build inputs privately. Diagnostic maps stay outside distribution. Product data and user-authored Scripts are never transformation inputs.

Run `npm test` here for focused fidelity, artifact-integrity and fail-closed dispatch checks. See the parent Desktop installer README for the existing pipeline and native-verification boundaries.
