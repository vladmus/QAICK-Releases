import {readFile,writeFile,readdir,lstat,mkdir,cp} from 'node:fs/promises';
import {resolve,join,relative,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {build,transform} from 'esbuild';
import JavaScriptObfuscator from 'javascript-obfuscator';

// Standing owner policy, canonical blob a243eed69198726c7b998cc8b865925b8141b20b.
// Build-only: never transform user Projects, captured evidence or user-authored scripts.
export const policy = 'qaick-production-protection-2026-11-25-v1';
export const options = Object.freeze({compact:true,seed:251125,identifierNamesGenerator:'hexadecimal',
 renameGlobals:false,renameProperties:false,stringArray:true,stringArrayThreshold:1,stringArrayEncoding:['base64'],
 controlFlowFlattening:false,deadCodeInjection:false,debugProtection:false,disableConsoleOutput:false,
 selfDefending:false,sourceMap:false,ignoreImports:true,unicodeEscapeSequence:false});
export const sha256 = value => createHash('sha256').update(value).digest('hex');
export const toolIdentity = sha256(Buffer.concat(await Promise.all(['index.mjs','cli.mjs','portable.mjs','package.json'].map(p=>readFile(new URL('./'+p,import.meta.url))))));
export async function copyNotices(repository,target) {
 await mkdir(target,{recursive:true});
 const visited=new Set();
 async function visit(name,from) {
  if(name.startsWith('@types/'))return;
  let dir=from,full,pkg;
  while(true){try{full=join(dir,'node_modules',name);pkg=JSON.parse(await readFile(join(full,'package.json'),'utf8'));break;}catch(e){if(e.code!=='ENOENT')throw e;const parent=dirname(dir);if(parent===dir)return;dir=parent;}}
  if(visited.has(full))return;visited.add(full);
  for(const file of await readdir(full,{withFileTypes:true}))if(file.isFile()&&/^(?:license|notice|copying|copyright)(?:[._-][\w-]+)?$/i.test(file.name))
   await cp(join(full,file.name),join(target,'LICENSE-'+name.replaceAll('/','-')+'-'+pkg.version+'-'+file.name.replaceAll('.','-')+'.txt'));
  for(const child of Object.keys({...pkg.dependencies,...pkg.optionalDependencies}))await visit(child,full);
 }
 const pkg=JSON.parse(await readFile(join(repository,'package.json'),'utf8'));
 for(const name of Object.keys({...pkg.dependencies,...pkg.peerDependencies}))await visit(name,repository);
}
const js = path => /\.(?:cjs|mjs|js)$/.test(path);
// A copy may reuse an actual transformation, never a caller's unchecked claim.
const protectedOutputs = new Map();
export async function files(root) {
 const result={};
 async function visit(dir) {for(const name of (await readdir(dir)).sort()) {
  const full=join(dir,name),stat=await lstat(full),path=relative(root,full).replaceAll('\\','/');
  if(stat.isSymbolicLink()) throw Error('Release payload cannot contain symlink: '+path);
  if(stat.isDirectory()) await visit(full); else if(stat.isFile()) result[path]=sha256(await readFile(full));
  else throw Error('Unsupported release file: '+path);
 }}
 await visit(resolve(root)); return result;
}
export function checkPaths(paths) {
 for(const path of paths) {
  if(/(?:^|\/)(?:node_modules|src|tests?|__tests__|docs|\.git|\.idea|local-packages)(?:\/|$)/i.test(path) ||
    /\.(?:ts|tsx|jsx|map|tsbuildinfo|tgz|log)$|(?:^|\/)(?:AGENTS\.md|package-lock\.json)$/i.test(path) || /\.test\./.test(path))
   throw Error('Prohibited production file: '+path);
  if(!/\.(?:js|mjs|cjs|json|html|css|svg|png|ico|icns|jpg|jpeg|webp|woff2?|ttf|md|txt)$/.test(path) && !/(?:^|\/)_(?:headers|redirects)$/.test(path))
   throw Error('File is not on the production allowlist: '+path);
  if(/\.(?:md|txt)$/.test(path) && !/(?:^|\/)(?:EULA|CREDITS|LICENSE[^/]*|NOTICE[^/]*)(?:\.(?:md|txt))?$/i.test(path))
   throw Error('Unnecessary documentation in production: '+path);
 }
}
export async function protectCode(code,{format='esm',platform='browser'}={}) {
 const minified=await transform(code,{minify:true,legalComments:'none',target:'es2022',format,sourcemap:'external',sourcefile:'private-input.js'});
 const obfuscated=JavaScriptObfuscator.obfuscate(minified.code,{...options,target:platform==='node'?'node':'browser-no-eval',sourceMap:true,sourceMapMode:'separate',sourceMapSourcesMode:'sources-content'});
 const result=obfuscated.getObfuscatedCode().replace(/\n?\/\/# sourceMappingURL=[^\r\n]*\s*$/,'');
 if(/sourceMappingURL|sourceURL=/.test(result)) throw Error('Debug source reference in protected output');
 const diagnostics=resolve('artifacts/private-protection-maps');await mkdir(diagnostics,{recursive:true});
 const key=sha256(JSON.stringify({code,format,platform,toolIdentity}));
 await writeFile(join(diagnostics,key+'.minify.map'),minified.map);
 await writeFile(join(diagnostics,key+'.obfuscate.map'),obfuscated.getSourceMap());
 await writeFile(join(diagnostics,key+'.json'),JSON.stringify({sourceSha256:sha256(code),outputSha256:sha256(result+'\n'),chain:['obfuscate.map','minify.map']})+'\n');
 const output=result+'\n';protectedOutputs.set(sha256(output),{inputSha256:sha256(code),outputSha256:sha256(output),kind:'bundled-minified-obfuscated'});
 return output;
}
export async function bundle(entry,out,{platform='node',format='esm',external=[],plugins=[]}={}) {
 const result=await build({entryPoints:[entry],bundle:true,write:false,outfile:out,metafile:true,platform,format,target:'es2022',minify:true,
  sourcemap:'external',legalComments:'none',external,plugins,
  ...(platform==='node'&&format==='esm'?{banner:{js:"import{createRequire as __qaickCreateRequire}from'node:module';const require=__qaickCreateRequire(import.meta.url);"}}:{})});
 const code=result.outputFiles.find(f=>!f.path.endsWith('.map')).text;
 const diagnostics=resolve('artifacts/private-protection-maps');await mkdir(diagnostics,{recursive:true});
 await writeFile(join(diagnostics,sha256(code)+'.bundle.map'),result.outputFiles.find(f=>f.path.endsWith('.map')).text);
 await writeFile(join(diagnostics,sha256(code)+'.inputs.json'),JSON.stringify(result.metafile)+'\n');
 await writeFile(out,await protectCode(code,{platform,format}));
}
export async function protectTree(root,{platform='browser',formats={},alreadyProtected=[]}={}) {
 const before=await files(root);checkPaths(Object.keys(before));const transformed={};
 for(const path of Object.keys(before)) {
  const file=join(root,path),source=await readFile(file,'utf8');
  if(js(path)) {
   if(alreadyProtected.includes(path)&&!protectedOutputs.has(before[path]))throw Error('Unverified upstream transformation: '+path);
   if(!alreadyProtected.includes(path)) await writeFile(file,await protectCode(source,{platform,format:formats[path]??(path.endsWith('.cjs')?'cjs':'esm')}));
   transformed[path]=protectedOutputs.get(sha256(await readFile(file)));
  } else if(path.endsWith('.html')) {
   let text=source;const blocks=[...text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];let count=0;
   for(const block of blocks) if(!/\bsrc\s*=/.test(block[1])&&block[2].trim()&&!/application\/(?:ld\+)?json/.test(block[1])) {
    text=text.replace(block[0],`<script${block[1]}>${await protectCode(block[2],{format:'iife',platform:'browser'})}</script>`);count++;
   }
   if(count){await writeFile(file,text);transformed[path]={inputSha256:before[path],outputSha256:sha256(text),kind:'inline-minified-obfuscated',blocks:count};}
  }
 }
 return {policy,toolIdentity,tools:{esbuild:'0.28.2',obfuscator:'5.10.1'},files:await files(root),transformed};
}
export async function verifyTree(root,receipt) {
 if(receipt.policy!==policy||receipt.toolIdentity!==toolIdentity) throw Error('Missing or obsolete protection evidence');
 const current=await files(root);checkPaths(Object.keys(current));
 if(JSON.stringify(current)!==JSON.stringify(receipt.files)) throw Error('Protection evidence does not match exact payload hashes');
 if(!Object.keys(current).some(js)) throw Error('No protected application JavaScript');
 for(const path of Object.keys(current)) {
  if(js(path)&&receipt.transformed?.[path]?.outputSha256!==current[path]) throw Error('Unverified JavaScript: '+path);
  if(js(path)&&receipt.transformed[path].kind!=='bundled-minified-obfuscated')throw Error('Missing required transformations: '+path);
  if(js(path)&&(!/^[a-f0-9]{64}$/.test(receipt.transformed[path].inputSha256)||receipt.transformed[path].inputSha256===current[path]))throw Error('No verified transformation: '+path);
  if(/\.(?:js|mjs|cjs|html|css)$/.test(path)) {
   const text=await readFile(join(root,path),'utf8');
   if(/sourceMappingURL\s*=|data:application\/json[^,]*;base64,/.test(text))throw Error('Public debug map: '+path);
   if(path.endsWith('.html')&&[...text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].some(m=>! /\bsrc\s*=|application\/(?:ld\+)?json/.test(m[1])&&m[2].trim())&&receipt.transformed?.[path]?.outputSha256!==current[path])throw Error('Unverified inline script: '+path);
  }
 }
 for(const path of Object.keys(current).filter(js))protectedOutputs.set(current[path],receipt.transformed[path]);
 return current;
}
export async function publishWeb(root,receiptPath,dispatch) {
 const receipt=JSON.parse(await readFile(receiptPath,'utf8'));
 await verifyTree(root,receipt);return dispatch();
}

export async function verifyArtifactEvidence(file,receiptPath=file+'.protection.json') {
 const receipt=JSON.parse(await readFile(receiptPath,'utf8'));
 if(receipt.policy!==policy||receipt.toolIdentity!==toolIdentity||receipt.kind!=='desktop-installer')throw Error('Missing or stale final-installer verification');
 if(receipt.sha256!==sha256(await readFile(file)))throw Error('Installer hash differs from verified artifact');
 for(const check of ['finalPayload','transformations','asar','obsoleteLooseFiles'])if(receipt.checks?.[check]!==true)throw Error('Unverified installer protection: '+check);
 if(!['linux','win32','darwin'].includes(receipt.platform)||receipt.platform!=='linux'&&receipt.checks.integrity!==true)throw Error('Missing supported ASAR integrity');
 return receipt;
}
export async function publishArtifacts(artifacts,dispatch) {
 if(!artifacts.length)throw Error('No verified release artifacts');
 for(const file of artifacts)await verifyArtifactEvidence(file);
 return dispatch();
}
